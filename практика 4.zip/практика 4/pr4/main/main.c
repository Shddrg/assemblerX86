#include <8051.h>

void delay(unsigned int x)
{
    while(x-- > 0)  
    {
        TH0 = (-10000) >> 8;   
        TL0 = -10000;            
        
        TR0 = 1;                
        do; while(TF0 == 0);    
        TF0 = 0;                
        TR0 = 0;                
    }
}

void main()
{
    // LED1 - 0x01 (P1.0)
    // LED2 - 0x02 (P1.1)
    // LED3 - 0x04 (P1.2)
    // LED4 - 0x08 (P1.3)
    // LED5 - 0x10 (P1.4)
    // LED6 - 0x20 (P1.5)
    // LED7 - 0x40 (P1.6)
    // LED8 - 0x80 (P1.7)
   
   
    unsigned char leds[8] = {
        0x05,  // LED1 + LED3
        0x0A,  // LED2 + LED4
        0x50,  // LED5 + LED7
        0xA0,  // LED6 + LED8
        0xA0,  // LED6 + LED8 - ???????
        0x50,  // LED5 + LED7
        0x0A,  // LED2 + LED4
        0x05   // LED1 + LED3
    };
    
    // ????????? ??? ????????
    unsigned int durations[4] = {500, 200, 200, 500};  
    
    unsigned char i;
    
    TMOD = 0x01;    
    
    while(1)      
    {
        for(i = 0; i < 8; i++)
        {
            P1 = leds[i];  // ??????? ?????????? ?? ????
            
            // ???? ???????? ?????
            if(i == 0 || i == 7)           
                delay(durations[0]);   
            else if(i == 1 || i == 6)       
                delay(durations[1]);   
            else if(i == 2 || i == 5)       
                delay(durations[2]);   
            else if(i == 3 || i == 4)       
                delay(durations[3]);   
        }
    }
}