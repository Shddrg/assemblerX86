;$MOD51	; This includes 8051 definitions for the Metalink assembler

;org 00h ;
;mov dptr,#00h ;
;mov r2,#0ffh ;
;mov r1,#055h ;
;test:
;mov a,r1 ;
;movx @dptr,a ;
;movx a,@dptr; 
;xrl a,#055h;
;jnz error;
;inc dptr;
;djnz r2,test;
;error

;END

$MOD51          

ORG 0000H       
    SJMP START

ORG 0030H       
START:
    MOV DPTR, #0100H    
    MOV R3, #1          ;4
    MOV R1, #55H        
    CLR P1.1   
	CLR P1.0         

TEST_BLOCK:
    MOV R2, #0          
    
INNER_LOOP:
    MOV A, R1           
    MOVX @DPTR, A       
    
    MOVX A, @DPTR       
    XRL A, R1           
    JNZ ERROR_FOUND     
    
    INC DPTR            ;stop yach
    DJNZ R2, INNER_LOOP 
    
    DJNZ R3, TEST_BLOCK 
    
SUCCESS_STOP:
    SETB P1.0
	SJMP HALT_ERROR   

ERROR_FOUND:
    SETB P1.1        
HALT_ERROR:
    SJMP HALT_ERROR     

END