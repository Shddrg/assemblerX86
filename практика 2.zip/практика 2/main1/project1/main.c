#include <8051.h>

unsigned int cycle1(unsigned char* massiv, unsigned int i)
{   
    while(1)
    {
        if((P3 && 0x02) != 1) { return i; }
        
        P2 = massiv[i];
        
        if((P1 & 0x02) != 0) 
        {
            i++; 
            if(i >= 10) { i = 0; }
            
            P2 = massiv[i];
            

            while((P1 & 0x02) != 0)
            {
                if((P3 && 0x02) != 1) { return i; }
            }
        }
    }
}
unsigned int cycle2(unsigned char* massiv, unsigned int i)
{   unsigned char j;
	for(;i<10;i++) 
		{ 	
			if((P3 && 0x02)== 1){return i;}
			P2=massiv[i];
			for(j=0;j<200;j++);
		}
	return 0;
}
void main()
{
	unsigned char massiv [11]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0xFF };
	//P1=massiv [10]
	unsigned char i = 0; 
	P1 = 0x00;
	P3 = 0x00;
	while(1)
	{
		if((P3 && 0x02)== 1) 
		{
			i = cycle1(&massiv, i);
		}else
		{
			i = cycle2(&massiv, i);
		}

	}  
}