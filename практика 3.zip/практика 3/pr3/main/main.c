#include <8051.h>

void delay(unsigned int time) {
    unsigned int i, j;
    for(i = 0; i < time; i++) {
        for(j = 0; j < 1; j++);
    }
}

void main(void) {
    unsigned char i;
    unsigned char pos = 0;
    
    unsigned char word[7];
    unsigned char buffer[16];

    word[0] = 164; 
    word[1] = 173; 
    word[2] = 169; 
    word[3] = 179; 
    word[4] = 177; 
    word[5] = 169; 
    word[6] = 170; 

    P0 = 0x38; P2 = 0x1; P2 = 0x0; delay(2);
    P0 = 0x38; P2 = 0x1; P2 = 0x0; delay(2);
    P0 = 0x38; P2 = 0x1; P2 = 0x0; delay(2);
    P0 = 0x0C; P2 = 0x1; P2 = 0x0; delay(2);
    P0 = 0x06; P2 = 0x1; P2 = 0x0; delay(2);
    P0 = 0x01; P2 = 0x1; P2 = 0x0; delay(2);

    while(1) {
        
        for(i = 0; i < 16; i++) {
            buffer[i] = 0x20;
        }
    
        for(i = 0; i < 7; i++) {
            if ((pos + i) < 16) {
                buffer[pos + i] = word[i];
            }
        }

        P0 = 0x80; 
        P2 = 0x1; P2 = 0x0;
        for(i = 0; i < 8; i++) {
            P0 = buffer[i];
            P2 = 0x3; P2 = 0x2;
        }

        P0 = 0xC0; 
        P2 = 0x1; P2 = 0x0;
        for(i = 8; i < 16; i++) {
            P0 = buffer[i];
            P2 = 0x3; P2 = 0x2;
        }

        pos++;
        
        if(pos >= 16) {
            pos = 0;
        } 
    }
}