$MOD51

    ORG 0000H
    LJMP MAIN

    ORG 0030H
MAIN:
    MOV P1, #00H        

    MOV TMOD, #02H      
    
    MOV TH0, #6         
    MOV TL0, #6

    SETB TR0            

WAVE_LOOP:
    ; 135 
WAIT_F0:
    JNB TF0, WAIT_F0    
    CLR TF0
	
    MOV P1, #255
    MOV P1, #254
    MOV P1, #252
    MOV P1, #251
    MOV P1, #249
    MOV P1, #248
    MOV P1, #246
    MOV P1, #245
    MOV P1, #244
	MOV P1, #242
    
	MOV P1, #241
    MOV P1, #239
    MOV P1, #238
    MOV P1, #236
    MOV P1, #235
    MOV P1, #234
    MOV P1, #232
    MOV P1, #231
    MOV P1, #229
    MOV P1, #228
    
	MOV P1, #226
    MOV P1, #225
    MOV P1, #224
    MOV P1, #222
    MOV P1, #221
    MOV P1, #219
    MOV P1, #218
    MOV P1, #216
    MOV P1, #215
    MOV P1, #214
    
	MOV P1, #212
    MOV P1, #211
    MOV P1, #209
    MOV P1, #208
    MOV P1, #206
    MOV P1, #205
    MOV P1, #204
    MOV P1, #202
    MOV P1, #201
    MOV P1, #199
    
	MOV P1, #198
    MOV P1, #196
    MOV P1, #195
    MOV P1, #194
    MOV P1, #192
    MOV P1, #191
    MOV P1, #189
    MOV P1, #188
    MOV P1, #186
    MOV P1, #185
    
	MOV P1, #184
    MOV P1, #182
    MOV P1, #181
    MOV P1, #179
    MOV P1, #178
    MOV P1, #176
    MOV P1, #175
    MOV P1, #174
    MOV P1, #172
    MOV P1, #171
    
	MOV P1, #169
    MOV P1, #168
    MOV P1, #166
    MOV P1, #165
    MOV P1, #164
    MOV P1, #162
    MOV P1, #161
    MOV P1, #159
    MOV P1, #158
    MOV P1, #156
    
	MOV P1, #155
    MOV P1, #154
    MOV P1, #152
    MOV P1, #151
    MOV P1, #149
    MOV P1, #148
    MOV P1, #146
    MOV P1, #145
    MOV P1, #144
    MOV P1, #142
    
	MOV P1, #141
    MOV P1, #139
    MOV P1, #138
    MOV P1, #136
    MOV P1, #135
    MOV P1, #134
    MOV P1, #132
    MOV P1, #131
    MOV P1, #129
    MOV P1, #128
    
	MOV P1, #126
    MOV P1, #125
    MOV P1, #124
    MOV P1, #122
    MOV P1, #121
    MOV P1, #119
    MOV P1, #118
    MOV P1, #116
    MOV P1, #115
    MOV P1, #114
    
	MOV P1, #112
    MOV P1, #111
    MOV P1, #109
    MOV P1, #108
    MOV P1, #106
    MOV P1, #105
    MOV P1, #104
    MOV P1, #102
    MOV P1, #101
    MOV P1, #99
    
	MOV P1, #98
    MOV P1, #96
    MOV P1, #95
    MOV P1, #94
    MOV P1, #92
    MOV P1, #91
    MOV P1, #89
    MOV P1, #88
    MOV P1, #86
    MOV P1, #85
    
	MOV P1, #84
    MOV P1, #82
    MOV P1, #81
    MOV P1, #79
    MOV P1, #78
    MOV P1, #76
    MOV P1, #75
    MOV P1, #74
    MOV P1, #72
    MOV P1, #71
    
	MOV P1, #69
    MOV P1, #68
    MOV P1, #66
    MOV P1, #65
    MOV P1, #63

WAIT_F1:
    JNB TF0, WAIT_F1    
    CLR TF0
    
    MOV P1, #63         

WAIT_F2:
    JNB TF0, WAIT_F2    
    CLR TF0

    MOV P1, #63
    MOV P1, #63
    MOV P1, #64
    MOV P1, #64
    MOV P1, #65
    MOV P1, #65
    MOV P1, #66
    MOV P1, #66
    MOV P1, #67
    MOV P1, #67
    

	MOV P1, #68
    MOV P1, #68
    MOV P1, #69
    MOV P1, #69
    MOV P1, #70
    MOV P1, #70
    MOV P1, #71
    MOV P1, #71
    MOV P1, #72
    MOV P1, #72
    
	MOV P1, #73
    MOV P1, #73
    MOV P1, #73
    MOV P1, #74
    MOV P1, #74
    MOV P1, #75
    MOV P1, #75
    MOV P1, #76
    MOV P1, #76
    MOV P1, #77
    
	MOV P1, #77
    MOV P1, #78
    MOV P1, #78
    MOV P1, #79
    MOV P1, #79
    MOV P1, #80
    MOV P1, #80
    MOV P1, #81
    MOV P1, #81
    MOV P1, #82
    
	MOV P1, #82
	MOV P1, #83
    MOV P1, #83
    MOV P1, #83
    MOV P1, #84
    MOV P1, #84
    MOV P1, #85
    MOV P1, #85
    MOV P1, #86
    MOV P1, #86
    
	MOV P1, #87
    MOV P1, #87
	MOV P1, #88
    MOV P1, #88
    MOV P1, #89
    MOV P1, #89
    MOV P1, #90
    MOV P1, #90
    MOV P1, #91
    MOV P1, #91
    
	MOV P1, #92
    MOV P1, #92
    MOV P1, #93
    MOV P1, #93
    MOV P1, #93
    MOV P1, #94
    MOV P1, #94
    MOV P1, #95
    MOV P1, #95
    MOV P1, #96
    
	MOV P1, #96
    MOV P1, #97
    MOV P1, #97
    MOV P1, #98
    MOV P1, #98
    MOV P1, #99
    MOV P1, #99
    MOV P1, #100
    MOV P1, #100
    MOV P1, #101
    MOV P1, #101
    
	MOV P1, #102
    MOV P1, #102
    MOV P1, #103
    MOV P1, #103
    MOV P1, #103
    MOV P1, #104
    MOV P1, #104
    MOV P1, #105
    MOV P1, #105
    MOV P1, #106
    
	MOV P1, #106
    MOV P1, #107
    MOV P1, #107
    MOV P1, #108
    MOV P1, #108
    MOV P1, #109
    MOV P1, #109
    MOV P1, #110
    MOV P1, #110
    MOV P1, #111
    
	MOV P1, #111
    MOV P1, #112
    MOV P1, #112
    MOV P1, #113
    MOV P1, #113
    MOV P1, #113
    MOV P1, #114
    MOV P1, #114
    MOV P1, #115
    MOV P1, #115
    MOV P1, #116
    
	MOV P1, #116
    MOV P1, #117
    MOV P1, #117
    MOV P1, #118
    MOV P1, #118
    MOV P1, #119
    MOV P1, #119
    MOV P1, #120
    MOV P1, #120
    MOV P1, #121
    MOV P1, #121
    MOV P1, #122
    MOV P1, #122
    MOV P1, #123
    MOV P1, #123
    MOV P1, #124
    MOV P1, #124
    MOV P1, #125
    MOV P1, #125
    MOV P1, #126
    MOV P1, #126
    MOV P1, #127

WAIT_F3:
    JNB TF0, WAIT_F3    
    CLR TF0
    
    MOV P1, #0          

WAIT_F4:
    JNB TF0, WAIT_F4    
    CLR TF0
    
    LJMP WAVE_LOOP      

    END