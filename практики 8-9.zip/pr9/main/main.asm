$MOD51

OFFSET      EQU     33H     ; smeh

ADC_SOC     BIT     0B6H    

            ORG     0000H   
            LJMP    MAIN

            ORG     0003H   
            LJMP    EXT0_ISR


            ORG     0030H   
EXT0_ISR:
            PUSH    ACC        
            MOV     A, R2
            XRL     A, #OFFSET 
            MOV     R2, A
            POP     ACC        
            RETI

;proga
MAIN:
            ; 1. inic
            MOV     P1, #00H   
            MOV     P2, #00H   
            
            
            MOV     R2, #00H   

            ; 2. set prer
            SETB    IT0        
            SETB    EX0        
            SETB    EA         

LOOP:
            ; 3. Start ACHP
            SETB    ADC_SOC     
            CLR     ADC_SOC     

            ; 4. read ACHP
            MOV     A, P1      

            ; 5. smech
            ADD     A, R2      

            ; 6. perepon
            JNC     OUTPUT     
            MOV     A, #0FFH   

            ; 7. exit CHAP
OUTPUT:
            MOV     P2, A      
            SJMP    LOOP       
            
            END