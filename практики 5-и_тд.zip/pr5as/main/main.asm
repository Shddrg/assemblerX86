$MOD51

        ORG 0000H
        LJMP START 

        ORG 0100H            
MASSIV:    
        DB 'Q','W','E','R','T'
        DB 'A','S','D','F','G'
        DB 'Z','X','C','V','B'

        ORG 0110H
NUMBER:
    MOV 38H, R2    
    MOV 39H, R3    
    MOV 3AH, R4     
    MOV 3BH, R5    

    MOV A, 39H     
    MOV B, #5       
    MUL AB        
    MOV R1, A      
    
    MOV A, 3BH    
    ADD A, R1     
    MOV R1, A     
    
    MOV DPTR, #MASSIV
    
    MOV A, R1
    MOVC A, @A+DPTR
    
    MOV P0, A       
    MOV P2, #01H  
    MOV P2, #02H  
    RET

        
ORG 0154H
DELAY_20MS:

        MOV TMOD, #01H

        MOV TH0, #0B1H
        MOV TL0, #0E0H

        CLR TF0
        SETB TR0       

WAIT_TIMER:
        JNB TF0, WAIT_TIMER

        CLR TR0
        CLR TF0
        
        RET
DELAY_OUTER:
        MOV R7, #250         
DELAY_INNER:
        DJNZ R7, DELAY_INNER ; 2 ????? * 250 = 500 ???
        DJNZ R6, DELAY_OUTER ; 500 ??? * 40 = 20000 ??? (20 ??)
        RET

DELAY_LOOP:
        INC 21H
        MOV A, 21H
        JNZ DELAY_CHK
        INC 20H

DELAY_CHK:
        MOV A, 20H
        CJNE A, 22H, DELAY_CMP
        MOV A, 21H
        CJNE A, 23H, DELAY_CMP
        SJMP DELAY_END

DELAY_CMP:
        JNC DELAY_END
        SJMP DELAY_LOOP

DELAY_END:
        RET


        ;ORG 017FH
START:
        MOV P0, #38H
        MOV P2, #01H
        MOV P2, #00H
        
        MOV P0, #80H
        MOV P2, #01H
        MOV P2, #00H

MAIN_LOOP:
        MOV 24H, #00H
        MOV 25H, #00H
        MOV 26H, #00H
        MOV 27H, #00H
        
        CLR A
        MOV 20H, A
        MOV 21H, A
        SJMP ROW_CHK

ROW_LOOP:
        MOV R2, 21H
        MOV A, #01H
        CJNE R2, #00H, SHIFT_ROW
        SJMP APPLY_ROW
SHIFT_ROW:
        ADD A, ACC
        DJNZ R2, SHIFT_ROW

APPLY_ROW:
        MOV R2, A
        MOV A, #0FFH
        CLR C
        SUBB A, R2
        MOV P1, A      ; ?????? ??????????? ???? ?? ??????? ???

        ; ???? ?????????? ???????????? ?? ???????????? ???????
        NOP
        NOP
        NOP

        CLR A
        MOV 22H, A     ; ???????? ???????? ????????
        MOV 23H, A

COL_LOOP:
        MOV A, P3      
        ORL A, #0E0H   
        INC A          
        JZ NEXT_COL

        MOV R2, 23H
        MOV R0, #00H
        MOV R1, #01H
        CJNE R2, #00H, SHIFT_COL
        SJMP CHECK_KEY

SHIFT_COL:
    MOV A, R1
    ADD A, R1
    MOV R1, A
    MOV A, R0
    ADDC A, R0
    MOV R0, A
    DJNZ R2, SHIFT_COL

CHECK_KEY:
        MOV A, #0FFH
        CLR C
        SUBB A, R1
        MOV R5, A      
        MOV A, #00H
        SUBB A, R0
        MOV R4, A

        
        LCALL DELAY_20MS
        

        MOV A, P3      
        ORL A, #0E0H   
        MOV R1, A
        MOV R0, #00H
        
        MOV A, R1
        CJNE A, 05H, NEXT_COL
        MOV A, R0
        CJNE A, 04H, NEXT_COL

        MOV R2, 20H
        MOV R3, 21H
        MOV R4, 22H
        MOV R5, 23H
        LCALL NUMBER

NEXT_COL:
        INC 23H
        MOV A, 23H
        JNZ COL_CHK
        INC 22H

COL_CHK:
        MOV A, 23H
        ADD A, #0FBH   
        MOV A, 22H
        ADDC A, #0FFH
        JNC COL_LOOP

NEXT_ROW:
        INC 21H
        MOV A, 21H
        JNZ ROW_CHK
        INC 20H

ROW_CHK:
        MOV A, 21H
        ADD A, #0FDH   
        MOV A, 20H
        ADDC A, #0FFH
        JNC ROW_LOOP
        LJMP MAIN_LOOP

        END