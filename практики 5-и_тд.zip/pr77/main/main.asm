$MOD51 

T2CON  DATA 0C8H
RCAP2L DATA 0CAH
RCAP2H DATA 0CBH
TL2    DATA 0CCH
TH2    DATA 0CDH

TF2    BIT  0CFH 
TR2    BIT  0CAH 
ET2    BIT  0ADH 

PWM_PIN BIT P1.0
BTN_UP  BIT P3.2 
BTN_DN  BIT P3.3 

DSEG AT 30H
DUTY:   DS 1    ;(30-50)
TICK:   DS 1    ;(0-99)


CSEG AT 0000H
    JMP MAIN

CSEG AT 0003H       ; break up b
    JMP INT0_ISR

CSEG AT 0013H       ; break dn b
    JMP INT1_ISR

CSEG AT 002BH       ; break SHIM
    JMP T2_ISR

; -------------------------------
CSEG AT 0050H
MAIN:
    MOV DUTY, #50   
    MOV TICK, #0
    CLR PWM_PIN

    SETB BTN_UP
    SETB BTN_DN

    MOV T2CON, #00H 
    MOV RCAP2H, #0FDH
    MOV RCAP2L, #7BH
    MOV TH2, #0FDH
    MOV TL2, #7BH

    SETB IT0        
    SETB IT1        

    SETB EX0        
    SETB EX1        
    SETB ET2        
    SETB EA         
    SETB TR2        

MAIN_LOOP:

    JB EX0, CHECK_DN_BTN      
    JNB BTN_UP, CHECK_DN_BTN  
    ACALL DELAY               
    SETB EX0                  

CHECK_DN_BTN:

    JB EX1, MAIN_LOOP_END     
    JNB BTN_DN, MAIN_LOOP_END 
    ACALL DELAY               
    SETB EX1                  

MAIN_LOOP_END:
    SJMP MAIN_LOOP

; --- up b ---
INT0_ISR:
    PUSH PSW
    PUSH ACC
    
    CLR EX0         ;off
    
    MOV A, DUTY
    CJNE A, #50, DO_INC_DUTY ; if not 50, up 
    SJMP END_INT0
DO_INC_DUTY:
    INC DUTY
END_INT0:
    POP ACC
    POP PSW
    RETI           

; --- dn b ---
INT1_ISR:
    PUSH PSW
    PUSH ACC
    
    CLR EX1         ; off
    
    MOV A, DUTY
    CJNE A, #30, DO_DEC_DUTY ; if not 30, dn
    SJMP END_INT1
DO_DEC_DUTY:
    DEC DUTY
END_INT1:
    POP ACC
    POP PSW
    RETI

; --- SHIM ---
T2_ISR:
    PUSH PSW        
    PUSH ACC        
    CLR TF2         
    INC TICK
    MOV A, TICK
    CJNE A, #100, COMPARE_PWM 
    MOV TICK, #0    
COMPARE_PWM:
    MOV A, TICK
    CLR C
    SUBB A, DUTY    
    JC SET_PIN_HIGH 
    CLR PWM_PIN     
    POP ACC         
    POP PSW         
    RETI
SET_PIN_HIGH:
    SETB PWM_PIN
    POP ACC         
    POP PSW         
    RETI
; --- dreb ---
DELAY:
    MOV R7, #20
DELAY_L1:
    MOV R6, #250
DELAY_L2:
    DJNZ R6, DELAY_L2
    DJNZ R7, DELAY_L1
    RET

END