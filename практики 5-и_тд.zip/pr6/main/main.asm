$MOD51  ; This includes 8051 definitions for the Metalink assembler

ORG 0000H
    JMP MAIN

ORG 0030H ;XX

MAIN:
    
    ; 1("A", "B", "C", "D", "E", "F")
    
    MOV 30H, #'A'
    MOV 31H, #'B'
    MOV 32H, #'C'
    MOV 33H, #'D'
    MOV 34H, #'E'
    MOV 35H, #'F'

    ; 2

    MOV TMOD, #20H   ; timer
    MOV TH1, #0FDH   ; 9600bit/s
    MOV PCON, #80H   ; 9600*2=19200bit/s
    MOV SCON, #50H   ; rezhim 1
    SETB TR1         ; on

    ; 3
    MOV R0, #30H     
    MOV R7, #06H     

    ; 4
SEND_LOOP:
    MOV A, @R0       ; take
    MOV SBUF, A      ; send

WAIT_TI:
    JNB TI, WAIT_TI  ; wait
    CLR TI           ; drop
    
    INC R0           
    DJNZ R7, SEND_LOOP 

    ; 5
DONE:
    SJMP DONE        

END